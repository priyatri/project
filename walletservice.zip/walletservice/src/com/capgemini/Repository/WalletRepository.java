package com.capgemini.Repository;

import com.capgemini.beans.Customer;

public interface WalletRepository
{

boolean Save(Customer c);
Customer FindByPhoneNumber(String phonenumber);


}
