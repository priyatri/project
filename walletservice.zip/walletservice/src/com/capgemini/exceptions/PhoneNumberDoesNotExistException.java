package com.capgemini.exceptions;

public class PhoneNumberDoesNotExistException extends Exception {

}
