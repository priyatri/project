package DAO;

import java.util.HashMap;
import java.util.Map;

public class IProduct_Impl implements IProduct {

	
	static Map<String,String> productDetails;
	static Map<String,Integer> salesDetails;
	static {
		productDetails=new HashMap<>();
		productDetails.put("lux", "Soap");
		productDetails.put("colgate", "Paste");
		productDetails.put("pears", "Soap");
		productDetails.put("sony", "Electronics");
		productDetails.put("samsung", "Electronics");
		productDetails.put("facepack", "Cosmatics");
		productDetails.put("facecream", "Cosmatics");
		
		salesDetails=new HashMap<>();
		salesDetails.put("lux", 100);
		salesDetails.put("colgate", 50);
		salesDetails.put("pears", 70);
		salesDetails.put("sony", 10000);
		salesDetails.put("samsung", 23000);
		salesDetails.put("facepack", 100);
		salesDetails.put("facecream", 60);
		
	}	
	@Override
	public int updateProducts(String category, int hike) throws ProductException{
		// TODO Auto-generated method stub
		
		int abc;
		String s="";int f=0;
		for(Map.Entry<String, String> x: productDetails.entrySet()) {
			if(x.getValue().equals(category))
			{
				s=x.getKey();
		abc=salesDetails.get(s);
		abc=abc+((abc*hike)/100);
		salesDetails.put(s, abc);
		f=1;
		}
			}
		
		if(f==0)
			throw new ProductException();
			
		
		return 1;
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		return salesDetails;
	}
	
	

}
