import DAO.ProductException;
import service.IProductService_Impl;
import service.IService;

public class test {

public static void main(String[] args) throws ProductException {
	
	IService serref=new IProductService_Impl();
	
	
	serref.updateProducts("Electronics", 10);
	
	System.out.println(serref.getProductDetails());
	
	serref.updateProducts("Soap", 20);
	System.out.println(serref.getProductDetails());
	
	serref.updateProducts("Cosmatics", 30);
	System.out.println(serref.getProductDetails());
	
	serref.updateProducts("Paste", 40);
	
	System.out.println(serref.getProductDetails());
	//serref.updateProducts("Pastwse", 40);
	
}
	
	
}
