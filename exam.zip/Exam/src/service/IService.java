package service;

import java.util.Map;

import DAO.ProductException;

public interface IService {

	
	public int updateProducts(String category,int hike)throws ProductException;   //throws ProductException
	public Map<String,Integer> getProductDetails()throws ProductException;
}
