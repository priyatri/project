package com.capgemini.storeclient.exceptions;

public class CategoryNotFoundException {

}
