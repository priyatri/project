package StepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Bean.RegistrationPOM;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	WebDriver driver;        // reference of WebDriver
	RegistrationPOM object;    // reference of RegistrationPOM class

	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation + "\\lib\\chromedriver.exe");
		driver = new ChromeDriver();
		object = new RegistrationPOM(driver);
		driver.get(projectLocation + "\\view\\RegistrationForm.html");
	}

	@Then("^Check the title of the Page and display the text whether matched or not$")
	public void check_the_title_of_the_Page_and_display_the_text_whether_matched_or_not() throws Throwable {
		String title = driver.getTitle();
		if (title.contentEquals("Welcome to JobsWorld"))
			System.out.println("****** Title Matched");
		else
			System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^User enter the wrong userId input or no data entered$")
	public void user_enter_the_wrong_userId_input_or_no_data_entered() throws Throwable {
		object.setUserId("");
		Thread.sleep(1000);
	}

	@When("^Clicks the button$")
	public void clicks_the_button() throws Throwable {
		object.setSubmit();
		Thread.sleep(1000);
	}

	@Then("^display the alert msg$")
	public void display_the_alert_msg() throws Throwable {
		Alert alert = driver.switchTo().alert();
		System.out.println("The alert:"+ alert.getText());
		Thread.sleep(1000);
		alert.accept();
		driver.close();
	}

	@When("^User enter the wrong password input or no data entered$")
	public void user_enter_the_wrong_password_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234"); 
		Thread.sleep(100);
		object.setPassword("");
		Thread.sleep(1000);
	}

	@When("^User enter the wrong name input or no data entered$")
	public void user_enter_the_wrong_name_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234");
		Thread.sleep(100);
		object.setPassword("pqrs4567");
		Thread.sleep(100);
		object.setName("");
		Thread.sleep(1000);
	}

	@When("^User enter the wrong address input or no data entered$")
	public void user_enter_the_wrong_address_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234");
		Thread.sleep(100);
		object.setPassword("pqrs4567"); 
		Thread.sleep(100);
		object.setName("Manoj"); 
		Thread.sleep(100);
		object.setAddress("");
		Thread.sleep(1000);
	}

	@When("^User enter the wrong Country input or no data entered$")
	public void user_enter_the_wrong_Country_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234"); 
		Thread.sleep(100);
		object.setPassword("pqrs4567"); 
		Thread.sleep(100);
		object.setName("Manoj");
		Thread.sleep(100);
		object.setAddress("Birdopur76"); 
		Thread.sleep(100);
		object.setCountry("(Please select a country)"); 
		Thread.sleep(1000);
	}

	@When("^User enter the wrong Zip Code input or no data entered$")
	public void user_enter_the_wrong_Zip_Code_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234");
		Thread.sleep(100);
		object.setPassword("pqrs4567");
		Thread.sleep(100);
		object.setName("Manoj"); 
		Thread.sleep(100);
		object.setAddress("Birdopur76");
		Thread.sleep(100);
		object.setCountry("India");
		Thread.sleep(100);
		object.setZipCode("");
		Thread.sleep(1000);
	}

	@When("^User enter the wrong Email id input or no data entered$")
	public void user_enter_the_wrong_Email_id_input_or_no_data_entered() throws Throwable {
		object.setUserId("manoj1234");
		Thread.sleep(100);
		object.setPassword("pqrs4567"); 
		Thread.sleep(100);
		object.setName("Manoj"); 
		Thread.sleep(100);
		object.setAddress("Birdopur76");
		Thread.sleep(100);
		object.setCountry("India"); 
		Thread.sleep(100);
		object.setZipCode("474011");
		Thread.sleep(100);
		object.setEmailId("mn12@.com");
		Thread.sleep(1000);
	}

	@When("^User leaves the radio Sex$")
	public void user_leaves_the_radio_Sex() throws Throwable {
		object.setUserId("manoj1234"); 
		Thread.sleep(100);
		object.setPassword("pqrs4567");	
		Thread.sleep(100);
		object.setName("Manoj");	
		Thread.sleep(100);
		object.setAddress("Birdopur76");	
		Thread.sleep(100);
		object.setCountry("India");
		Thread.sleep(100);
		object.setZipCode("474011");	
		Thread.sleep(100);
		object.setEmailId("manojs@gmail.com");	
		Thread.sleep(1000);
		
	}

	@When("^User enter the english checkbox by default$")
	public void user_enter_the_english_checkbox_by_default() throws Throwable {
		object.setUserId("manoj1234"); 
		Thread.sleep(100);
		object.setPassword("pqrs4567");
		Thread.sleep(100);
		object.setName("Manoj");
		Thread.sleep(100);
		object.setAddress("Birdopur76");
		Thread.sleep(100);
		object.setCountry("India"); 
		Thread.sleep(100);
		object.setZipCode("474011");
		Thread.sleep(100);
		object.setEmailId("manojs@gmail.com");
		Thread.sleep(100);
		object.setGender("html/body/form/ul/li[16]/input");
		Thread.sleep(100);
		object.setLanguage();
		Thread.sleep(1000);
	}

	@When("^click the Submit button$")
	public void click_the_Submit_button() throws Throwable {
		object.setSubmit();
	}
}
