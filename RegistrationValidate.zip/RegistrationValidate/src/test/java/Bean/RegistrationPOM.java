package Bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPOM {

	WebDriver driver;             // making the reference of WebDriver
	
	@FindBy(id = "usrID")        //To find by userId
	@CacheLookup
	WebElement userId;
	
	@FindBy(name = "passid")    //To find by password
	@CacheLookup
	WebElement password;
	
	@FindBy(id = "usrname")     //To find by userName
	@CacheLookup
	WebElement name;
	
	@FindBy(id = "addr")        //To find by address
	@CacheLookup
	WebElement address;
	
	@FindBy(name = "country")     //To find by country
	@CacheLookup
	WebElement country;
	
	@FindBy(name = "zip")         //To find by zipCode
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(name = "email")       //To find by emailAddress
	@CacheLookup
	WebElement emailId;
	
	@FindBy(name = "sex")        //To find by Gender
	@CacheLookup
	WebElement gender;
	
	@FindBy(name = "en")         //To find by language
	@CacheLookup
	WebElement language;
	
	@FindBy(name = "submit")
	@CacheLookup
	WebElement submit;

            //  making the constructor of RegistrationPOM class

	public RegistrationPOM(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	     // making the getter-setter for all fields

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String suserId) {    //setting userId by sending keys
		this.userId.sendKeys(suserId);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String spassword) {     //setting password by sending keys
		this.password.sendKeys(spassword);
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String sname) {      //setting name by sending keys
		this.name.sendKeys(sname);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String saddress) {        //setting address by sending keys
		this.address.sendKeys(saddress);
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String scountry) {               //setting country by selecting drop-down box
		Select dropCountry = new Select(country);
		dropCountry.selectByVisibleText(scountry);
	}

	public WebElement getZipCode() {
		return zipCode;
	}

	public void setZipCode(String szipCode) {          //setting zipCode by sending keys
		this.zipCode.sendKeys(szipCode);
	}

	public WebElement getEmailId() {
		return emailId;
	}

	public void setEmailId(String semailId) {             //setting emailId by sending keys
		this.emailId.sendKeys(semailId);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = driver.findElement(By.xpath(gender));      //setting gender from .xpath
		this.gender.click();
	}

	public WebElement getLanguage() {
		return language;
	}

	public void setLanguage() {             //setting language by clicking
		this.language.click();
	}
	
	public WebElement getSubmit() {
		return submit;
	}
	
	public void setSubmit() {
		this.submit.click();
	}
}
