package cm.cg.Exception;

public class FeedbackRatingException extends Exception
{

}
