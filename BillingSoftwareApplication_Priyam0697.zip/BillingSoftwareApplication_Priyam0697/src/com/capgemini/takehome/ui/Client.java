package com.capgemini.takehome.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO_Impl;
import com.capgemini.takehome.exception.ProductException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.IProductService_Impl;

public class Client {
	public static void main(String[] args)throws ProductException
	{
		IProductService aser=new IProductService_Impl();
		Scanner sc=new Scanner(System.in);
		int productCode;
		int choice;
		IProductService_Impl pser= new IProductService_Impl();
		List<Product> product=new ArrayList<Product>();
		while(true)
		{
		System.out.println("enter the product code");
		int i=sc.nextInt();
		System.out.println("enter the quantity");
		int k=sc.nextInt();
		System.out.println("Enter 1 to generate bill by entering product code and quantity");
		System.out.println("Enter 2 to Exit"); 
		choice=sc.nextInt();
		switch (choice)
		{
		
		case 1:			
			System.out.println(aser.getProductDetails(i));
			break;
		case 2:
			System.exit(0);
			break;
			default :System.out.println("wrong choice");
		}
			 
		}
		
	}

}
