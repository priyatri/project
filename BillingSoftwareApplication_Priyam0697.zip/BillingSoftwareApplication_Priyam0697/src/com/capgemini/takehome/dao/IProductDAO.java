package com.capgemini.takehome.dao;

import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductException;

public interface IProductDAO
{
Product getProductDetails(int productCode)throws ProductException;
public Map<Integer, Product> getProductDetails()throws ProductException;

}
