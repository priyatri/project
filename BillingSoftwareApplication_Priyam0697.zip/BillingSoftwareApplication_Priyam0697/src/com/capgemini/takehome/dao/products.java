package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;

public enum products {
	;

	public static Product entrySet() {
		return null;
		
	
	}

}
