package com.capgemini.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductException;

public class IProductDAO_Impl implements IProductDAO {
	
	
	


	@Override
	public Product getProductDetails(int productCode) throws ProductException {
		int i,j;
		String s="";int f=0;

				for(Map.Entry<Integer, Product>x: product.entrySet()) {
					if(x.getValue().equals(productCode))
					{
						j=x.getKey();
						Product.get(j);
						f=1;
					}
						
					}
				if(f==0)
					throw new ProductException();
		
		
	}

	@Override
	public Map<Integer, Product> getProductDetails() throws ProductException {
		return getProductDetails();
	}
}

	
