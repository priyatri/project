package com.capgemini.takehome.service;

import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.exception.ProductException;

public class IProductService_Impl implements IProductService
{
	IProductDAO daoref;
	
	public IProductService_Impl() {
	
		this.daoref = daoref;
	}

	@Override
	public Product getProductDetails(int productCode) throws ProductException {
		
		return daoref.getProductDetails(productCode);
	}

	@Override
	public Map<Integer, Product> getProductDetails() throws ProductException {
		
		return daoref.getProductDetails();
	}

}
